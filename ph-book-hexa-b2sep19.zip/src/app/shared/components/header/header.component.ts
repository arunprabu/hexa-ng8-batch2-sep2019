import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartDataService } from '../../services/cart-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  defaultCartItemsList: any[];

  constructor(private router: Router, private cartDataService: CartDataService) { }

  ngOnInit() {
    this.cartDataService.latestCartItems.subscribe((pdtList) => {
      this.defaultCartItemsList = pdtList;
    })
  }

  gotoCartPage() {
    this.router.navigate(['products', 'cart']);
  }
}
