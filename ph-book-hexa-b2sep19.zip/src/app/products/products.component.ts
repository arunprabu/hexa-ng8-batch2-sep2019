import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { CartDataService } from '../shared/services/cart-data.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styles: []
})
export class ProductsComponent implements OnInit {

  productList: any[];

  constructor(private product: Product, private cartDataService: CartDataService) { }

  ngOnInit() {
    this.productList = this.product.getProductList()
    console.log(this.productList);
  }

  onAddToCart(pdt) {
    this.cartDataService.updateCart(pdt);
  }

}
