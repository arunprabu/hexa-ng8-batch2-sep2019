import { Component, OnInit } from '@angular/core';
import { CartDataService } from '../../shared/services/cart-data.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styles: []
})
export class CartComponent implements OnInit {

  cartItemList: any[];

  constructor(private cartDataService: CartDataService) { }

  ngOnInit() {
    //Step 3: Subscribe the observable 
    this.cartDataService.latestCartItems.subscribe(pdtList => {
      console.log(pdtList);
      this.cartItemList = pdtList;
    });
  }

}
