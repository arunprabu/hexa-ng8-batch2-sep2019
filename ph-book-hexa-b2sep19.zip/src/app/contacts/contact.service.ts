import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Contact } from './contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private http: HttpClient) { }

  //Step1: Get the data from Component 
  createContact(contactData: Contact): Promise<Contact> {
    console.log(contactData);

    //Using Promises//
    let promise = new Promise((resolve, reject) => {
      //ajax 
      this.http.post("http://jsonplaceholder.typicode.com/users", contactData)
        .toPromise()
        .then((res: Contact) => {
          console.log(res);
          resolve(res);
        })
        .catch(err => {
          console.log(err);
          reject(err);
        })
    });
    return promise as Promise<Contact>;
  }

  getContacts(): Observable<Contact[]> {
    return this.http.get("https://jsonplaceholder.typicode.com/users")
      .pipe(map((resp: Contact[]) => { //Step3: Get the Resp from REST API 
        console.log(resp);
        //Step4: Send the resp back to the Component 
        return resp;
      }))
  }

  getContactById(id): Observable<Contact> { //1. getting id from component
    //2. send call to rest api 
    return this.http.get("https://jsonplaceholder.typicode.com/users/" + id)
      .pipe(map((res: Contact) => { //3. get the response from rest api 
        console.log(res);
        return res; //4. send it back to the component
      }));
  }

  updateContact(contactData: Contact) { //1. getting data from component
    //2. send call to rest api 
    return this.http.put("https://jsonplaceholder.typicode.com/users/" + contactData.id, contactData)
      .pipe(map((res: Contact) => {   //3. get the response from rest api 
        console.log(res);
        return res;  //4. send it back to the component
      }));
  }

}
