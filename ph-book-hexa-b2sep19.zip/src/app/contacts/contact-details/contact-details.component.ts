import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { ActivatedRoute } from '@angular/router';

declare var $: any;

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styles: []
})
export class ContactDetailsComponent implements OnInit {

  contactData: any;
  duplicateContactData: any;
  contactId: string;
  isSaved: boolean;

  constructor(private contactService: ContactService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.contactId = this.activatedRoute.snapshot.paramMap.get("id");
    console.log(this.contactId);

    //send rest api calls from here
    this.contactService.getContactById(this.contactId)
      .subscribe((res: any) => {
        console.log(res);
        //store the data in variable and then display in html
        this.contactData = res;
      });
  }

  openEditModal() {
    //open the modal
    $("#editContactModal").modal('show');
    //duplicate the data
    this.duplicateContactData = JSON.parse(JSON.stringify(this.contactData));
  }

  onUpdateContact() {
    console.log(this.duplicateContactData);
    //1. send data to services
    this.contactService.updateContact(this.duplicateContactData)
      .subscribe((res: any) => { //2. get the response from services
        console.log(res);
        if (res && res.id) {
          this.contactData = res;
          this.isSaved = true;
        }
      });
  }
}
