import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CebComponent } from './ceb/ceb.component';

@Component({
  selector: 'app-concepts',
  templateUrl: './concepts.component.html',
  styles: [
    `
      .greenText{
        color: green;
      }
    `
  ]
})
export class ConceptsComponent implements OnInit, AfterViewInit {

  //variables, consts 
  //String Interpolation related 
  appName: string = "Phone Book";
  //Todo: age as number with value 20 
  age: number = 20;
  //Todo: isLoggedIn as boolean and with value false 
  isLoggedIn: boolean = false;

  //array 
  //way #1 
  skillsList: string[] = ['html', 'css', 'js'];
  //way #2
  skillsList2: Array<string> = ['nodejs', 'react', 'graphql'];

  //==============
  //Prop Binding Related 
  devName: string = "Arun";

  //=========
  // Two Way binding 
  courseName: string = "Angular";

  //custom event binding
  profileData: any;

  @ViewChild(CebComponent, { 'static': true }) cebData: CebComponent;

  //structural directives
  isAuthenticated: boolean = true;

  menuList: string[] = [
    'Home', 'About', 'Contact', 'Products'
  ];

  constructor() {

  }

  ngOnInit() {

  }

  //parent comp has to Wait till child component's data are set up 
  ngAfterViewInit() {
    console.log(this.cebData);
  }

  // for Event Binding 
  onBtnClick(evt) {
    console.log(evt);
    alert("wow.. it works");
  }
  //custom prop binding
  getMyExperience() {
    return 40;
  }

  //custom event binding
  //Step 4: Receive the data handler and store in variable
  profileLoadedHandler(evt) {
    console.log(evt);
    //storing the data in variable to display in html 
    this.profileData = evt;
  }

}
