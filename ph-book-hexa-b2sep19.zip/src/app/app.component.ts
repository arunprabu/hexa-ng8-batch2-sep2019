import { Component } from '@angular/core';

//Decorator 
@Component({
  selector: 'app-root', // Step4: exposed in a selector -- must 
  templateUrl: './app.component.html', //html - must -- and only one 
  styleUrls: ['./app.component.scss'] //css  -- optional and can be many as well 
})

//ts 
export class AppComponent {
  title = 'ph-book-hexa-b2sep19';
}
