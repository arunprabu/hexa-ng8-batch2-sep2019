import { Component, OnInit, OnDestroy } from '@angular/core';
import { ContactService } from './contact.service';
import { Subscription } from 'rxjs';
import { Contact } from './contact.model';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styles: []
})
export class ContactsComponent implements OnInit, OnDestroy {
  contactList: Contact[];
  contactsSubscription: Subscription;

  constructor(private contactService: ContactService) {
    console.log("Inside Constructor");
  }

  ngOnInit() {
    console.log("Inside ngOnInit");
    //ideal place to send server side calls
    this.contactsSubscription = this.contactService.getContacts()
      .subscribe(
        (res: Contact[]) => {
          console.log(res);
          this.contactList = res;
        },
        (err: any) => {
          console.log('HTTP Error', err);
        },
        () => {
          console.log('HTTP request completed.')
        }
      );
  }

  ngOnDestroy() {
    console.log("on Destroy");
    //ideal place to delete the data, unsubscribe, stop intervals 
    this.contactsSubscription.unsubscribe();
    if (this.contactList) {
      this.contactList.length = 0;
    }
  }

}
