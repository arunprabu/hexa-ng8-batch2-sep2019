import { Injectable } from '@angular/core';

export interface IContact {
    id: number,
    name: string,
    phone: string,
    email: string
}

//will make the class dep injectable
@Injectable({
    providedIn: 'root'
})
//Model
export class Contact implements IContact {
    id: number;
    name: string;
    phone: string;
    email: string;

    //util methods should go here

}
