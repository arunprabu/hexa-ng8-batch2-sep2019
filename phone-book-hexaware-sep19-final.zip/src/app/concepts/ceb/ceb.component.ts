import { Component, OnInit, EventEmitter, Output, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-ceb',
  templateUrl: './ceb.component.html',
  styles: []
})
export class CebComponent implements OnInit {

  //Step1: Define custom event -- output decorator will make the below as custom event 
  @Output() onProfileLoaded: EventEmitter<any> = new EventEmitter();

  courseData: any = {
    name: 'angular',
    days: 10
  }

  constructor() {
    console.log("Inside Constructor");
  }

  //life cycle hook
  ngOnInit() {
    console.log("inside ngOnInit");
  }

  onLoadProfileClick() {
    //Step 2: Trigger/Emit the event
    this.onProfileLoaded.emit({ name: 'Arun', city: 'Chennai' });
  }


}
