import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-cpb',
  templateUrl: './cpb.component.html',
  styles: []
})
export class CpbComponent implements OnInit {

  //@Input() will make age as property -- used in app-cpb selector -- see concepts.comp.html 
  @Input() age: number = 20;



  constructor() { }

  ngOnInit() {
  }

}
