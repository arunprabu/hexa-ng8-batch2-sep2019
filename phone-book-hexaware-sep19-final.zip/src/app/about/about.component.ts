import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styles: []
})
export class AboutComponent implements OnInit {

  lastSignedIn: Date = new Date();

  productData: any = {
    id: 1,
    name: "Apple",
    category: "Fruits",
    price: "$2.76"
  };

  loremIpsum: string = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique sint animi, nemo voluptatum libero natus sequi quos, culpa pariatur voluptates qui odit itaque, soluta quibusdam enim quis eveniet. Beatae, repellat?';

  constructor() { }

  ngOnInit() {
  }

}
