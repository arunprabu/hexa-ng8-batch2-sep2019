import { Component } from '@angular/core';

//Decorator 
@Component({
  selector: 'app-root', //element selector -- must 
  templateUrl: './app.component.html', //html -- one template mandatory 
  styleUrls: ['./app.component.scss'] //css / scss -- can be multiple
})

//ts -- class must
export class AppComponent {
  //variables, const 
  //methods 
}
