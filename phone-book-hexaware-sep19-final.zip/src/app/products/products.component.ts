import { Component, OnInit } from '@angular/core';
import { Product } from './product.model';
import { CartDataService } from '../shared/services/cart-data.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styles: []
})
export class ProductsComponent implements OnInit {
  productList: any[];

  constructor(private productData: Product, private cartDataService: CartDataService) { }

  ngOnInit() {
    this.productList = this.productData.getProductList();
  }

  onAddToCart(pdt) {
    this.cartDataService.updateCart(pdt);
  }
}
