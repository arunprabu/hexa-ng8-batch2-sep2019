import { Component, OnInit, OnDestroy } from '@angular/core';
import { CartDataService } from '../../shared/services/cart-data.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styles: []
})
export class CartComponent implements OnInit, OnDestroy {

  cartItemList: any[];
  cartSubscription: Subscription;

  constructor(private cartDataService: CartDataService) { }

  ngOnInit() {
    this.cartSubscription = this.cartDataService.latestCartItems.subscribe((pdtList: any) => {
      console.log(pdtList);
      this.cartItemList = pdtList;
    })
  }

  ngOnDestroy() {
    this.cartSubscription.unsubscribe();
  }
}
