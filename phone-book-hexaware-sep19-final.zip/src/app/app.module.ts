import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//prime ng 
import { CalendarModule } from 'primeng/calendar';
import { ChartModule } from 'primeng/chart';
import { ToastModule } from 'primeng/toast';

//firebase
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { NavComponent } from './shared/components/nav/nav.component';
import { AboutComponent } from './about/about.component';
import { ConceptsComponent } from './concepts/concepts.component';
import { CpbComponent } from './concepts/cpb/cpb.component';
import { CebComponent } from './concepts/ceb/ceb.component';
import { ProductsModule } from './products/products.module';
import { ContactsModule } from './contacts/contacts.module';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { PrimengComponent } from './primeng/primeng.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthInterceptor } from './shared/interceptors/auth-interceptor';
import { EllipsisPipe } from './shared/pipes/ellipsis.pipe';
import { ColorizerDirective } from './shared/directives/colorizer.directive';


// Your web app's Firebase configuration
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDMG6kqy3wFANlJSyJFi9cj3tD3yvP3osI",
  authDomain: "hexa-ng-b1-auth.firebaseapp.com",
  databaseURL: "https://hexa-ng-b1-auth.firebaseio.com",
  projectId: "hexa-ng-b1-auth",
  storageBucket: "",
  messagingSenderId: "568982549306",
  appId: "1:568982549306:web:682ff939e9cde71f791603"
};

//Decorator 
//Main Switching box 
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    ConceptsComponent,
    AboutComponent,
    CpbComponent,
    CebComponent,
    PageNotFoundComponent,
    PrimengComponent,
    SigninComponent,
    SignupComponent,
    EllipsisPipe,
    ColorizerDirective
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CalendarModule,
    ChartModule,
    ToastModule,

    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireAuthModule,
    AngularFirestoreModule,

    FormsModule,
    HttpClientModule,
    ProductsModule,
    ContactsModule,
    AppRoutingModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  // Step3: AppModule should be bootstrapped with a Component
  bootstrap: [AppComponent]
})
export class AppModule { }
