import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConceptsComponent } from './concepts/concepts.component';
import { AboutComponent } from './about/about.component';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { PrimengComponent } from './primeng/primeng.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthGuard } from './shared/guards/auth.guard';

// configuring the routes 
const routes: Routes = [
  // syntax path: string, component: ComponentClass
  { path: '', component: ConceptsComponent },
  { path: 'concepts', component: ConceptsComponent, canActivate: [AuthGuard] },
  { path: 'about', component: AboutComponent },
  { path: 'signin', component: SigninComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'primeng', component: PrimengComponent, canActivate: [AuthGuard] },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], // Registering the routes
  exports: [RouterModule]
})
export class AppRoutingModule { }
