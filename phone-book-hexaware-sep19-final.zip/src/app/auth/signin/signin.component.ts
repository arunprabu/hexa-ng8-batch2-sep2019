import { Component, OnInit } from '@angular/core';
import { NgForm } from '../../../../node_modules/@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styles: []
})
export class SigninComponent implements OnInit {

  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  signInHandler(loginData: NgForm) {
    console.log(loginData.value);
    //connect to service 
    //send the above data to it
    let status = this.authService.login(loginData.value);

    console.log(status);
  }
}
