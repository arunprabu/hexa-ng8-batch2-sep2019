import { Injectable } from '@angular/core';

import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isLoggedIn: boolean;

  constructor(private ngFireAuth: AngularFireAuth, private router: Router) { }

  signup(formData) {
    console.log(formData);

    this.ngFireAuth.auth.createUserWithEmailAndPassword(formData.email, formData.password)
      .then((status: any) => {
        console.log(status);
        this.isLoggedIn = false;
        //redirecting upon successful reg 
        this.router.navigate(['signin']);
      }, (err) => {
        console.log(err);
        //handle that error
      });

  }

  login(loginData) {
    console.log(loginData);
    this.ngFireAuth.auth.signInWithEmailAndPassword(loginData.email, loginData.password)
      .then((status) => {
        console.log(status);
        //store in localStorage 
        localStorage.setItem("auth-token", status.user.refreshToken);
        this.isLoggedIn = true;
        this.router.navigate(['concepts']);
      }, (err) => {
        console.log(err);
        alert("check console.log pls ");
      });
  }

  logout() {
    this.ngFireAuth.auth.signOut()
      .then((status) => {
        console.log(status);
        this.isLoggedIn = false;
        localStorage.removeItem("auth-token");
      });

  }

  isAuthenticated() {
    return this.isLoggedIn;
  }
}
