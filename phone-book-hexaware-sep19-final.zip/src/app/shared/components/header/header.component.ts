import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartDataService } from '../../services/cart-data.service';
import { Subscription } from 'rxjs';

//Decorator
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  cartItemsCount: number;
  cartSubscription: Subscription;

  constructor(private router: Router, private cartDataService: CartDataService) { }

  ngOnInit() {
    this.cartSubscription = this.cartDataService.latestCartItems.subscribe((pdtList: any) => {
      console.log(pdtList);
      this.cartItemsCount = pdtList.length;
    })
  }

  gotoCartPage() {
    this.router.navigate(['products', 'cart']);
  }
}
