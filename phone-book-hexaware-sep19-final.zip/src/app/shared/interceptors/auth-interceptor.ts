import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

export class AuthInterceptor implements HttpInterceptor {

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let _authToken = localStorage.getItem("auth-token");
        //modify the req header 
        request = request.clone({ //update it with bearer token and return 
            setHeaders: {
                Authorization: "Bearer " + _authToken
            }
        });

        console.log(request);

        return next.handle(request); // returing it 
    }

}