import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ellipsis'
})
export class EllipsisPipe implements PipeTransform {

  constructor() {

  }

  transform(value: any, ...args: any[]): any {
    // 
    console.log(value); // on what the pipe is used
    console.log(args); // parameters passed in pipe 

    if (args && args.length > 0) {
      let _limit = args[0];
      value = value.substr(0, _limit);
      return value + "...";
    } else {
      return value + "...";
    }
  }

}
