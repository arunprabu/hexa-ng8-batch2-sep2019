import { Directive, OnInit, ElementRef } from '@angular/core';

// ng g d colorizer
@Directive({
  selector: '[appColorizer]'
})
export class ColorizerDirective implements OnInit {

  // @HostListener() can be used when this directive deals with event

  constructor(private elementRef: ElementRef) {
    console.log("Inside constr in colorizr directive");
    console.log(this.elementRef.nativeElement);

    let _el = this.elementRef.nativeElement;
    _el.style.backgroundColor = "yellow";
    _el.style.height = "200px";

    // you can use angular's api -- Renderer2
  }

  ngOnInit() {

  }
}
