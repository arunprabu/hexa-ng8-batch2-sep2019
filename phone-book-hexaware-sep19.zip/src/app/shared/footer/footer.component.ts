import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: `
    <footer class="text-center">
      <hr>
      <app-nav>
        <li class="nav-item">
            <a class="nav-link" href="/">Go to Top</a>
        </li>
      </app-nav>
      <p class="colorize" >Copyright &copy; 2019</p>
    </footer>
  `,
  styles: [
    `
      .colorize{
        color: green;
      }
    `
  ]
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
