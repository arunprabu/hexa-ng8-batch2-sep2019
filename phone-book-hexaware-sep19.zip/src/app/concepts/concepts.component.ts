import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CebComponent } from './ceb/ceb.component';

@Component({
  selector: 'app-concepts',
  templateUrl: './concepts.component.html',
  styles: [
    `
    .greenText{
      color: green;
    }
    `
  ]
})
export class ConceptsComponent implements OnInit, AfterViewInit {
  //variables, consts 
  //String Interpolation 
  appName: string = "Phone Book";
  age: number = 20;
  isLoggedIn: boolean = false;
  //array way  #1 
  skillsList: string[] = ['html', 'css', 'js'];
  // array way #2
  skillsList2: Array<string> = [
    'nodejs', 'react', 'graphql'
  ];

  //Property Binding 
  devName: string = "Arun";

  //two way binding related
  courseName: string = "Angular";

  //for custom property binding
  ageOfPerson: number = 100;

  //for custom event Binding
  profileData: any;

  //for View Child 
  @ViewChild(CebComponent, { 'static': true }) cebData;


  //directives
  isAuth: boolean = false;
  courseList: string[] = [
    'ng', 'react', 'nodejs', 'graphql'
  ]

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() { //will wait till child component's data are setup 
    console.log(this.cebData);
  }

  //for prop binding 
  isAuthenticated(): boolean {
    return true;
  }

  //event binding
  onBtnClick(evt): void {
    console.log(evt);
    alert("Wow.. click works");
  }

  //custom prop binding related
  getAge(): number {
    return 75;
  }

  //custom event binding related
  //Step4: Receive the data with event Handler
  profileLoadedHandler(evt: any) {
    console.log(evt);
    //Step 5: storing it in varible, so that display in concepts.comp.hmtl
    this.profileData = evt;
    console.log("Event fired");
  }


}



