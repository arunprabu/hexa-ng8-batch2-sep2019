import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { ActivatedRoute } from '@angular/router';

//to use jquery within angular component
declare var $: any;

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styles: []
})
export class ContactDetailsComponent implements OnInit {
  contactData: any;
  duplicateContactData: any;
  isSaved: boolean;

  contactId: string;
  constructor(private contactService: ContactService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.contactId = this.route.snapshot.paramMap.get("id");
    this.contactService.getContactById(this.contactId)
      .subscribe((res: any) => {
        console.log(res);
        this.contactData = res;
      });
  }

  openEditModal() {
    //open modal thru TS/ JS
    $('#editContactModal').modal('show');
    this.isSaved = false;
    //duplicate obj
    this.duplicateContactData = JSON.parse(JSON.stringify(this.contactData));
  }

  onUpdataHandler() {
    console.log(this.duplicateContactData);

    // 1. send the above data to services
    this.contactService.updateContact(this.duplicateContactData)
      .subscribe((res: any) => { // 2. subscribe the resp from the services
        console.log(res);
        if (res && res.id) {
          this.isSaved = true;
          this.contactData = res;

          //Todo: Close the modal automatically after 5 sec... hint: use timeout in JS 
          setTimeout(() => {
            $('#editContactModal').modal('hide');
          }, 5000);
        }
      })


  }

}
