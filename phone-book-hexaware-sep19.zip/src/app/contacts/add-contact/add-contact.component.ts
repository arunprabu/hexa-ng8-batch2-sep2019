import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styles: []
})
export class AddContactComponent implements OnInit {

  //Step 1: Create Form group
  contactForm: FormGroup;
  isSaved: boolean;

  constructor(private contactService: ContactService) { //Dep Injection

  }

  ngOnInit() {
    //Step 2: 
    this.contactForm = new FormGroup({
      //Step3: 
      // we'll create new form controls 
      name: new FormControl('', Validators.required), //Step6 -- add validators
      phone: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ])
    });
  }

  async onAddContactSubmit() {
    //1. get the data from contact form
    console.log(this.contactForm.value);
    //2. send the data to services 
    //2.1. connect to the services using dep injection
    //2.2. send the data to a method in the service

    let status: any = await this.contactService.createContact(this.contactForm.value);

    console.log(status);
    if (status && status.id) {
      this.isSaved = true;
    }
  }

}
