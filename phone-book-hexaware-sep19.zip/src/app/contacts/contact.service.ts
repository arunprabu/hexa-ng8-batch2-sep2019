import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { of } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: "root"
})
export class ContactService {
  API_URL: string = "https://jsonplaceholder.typicode.com/users/";

  // Client to connect to REST API 
  constructor(private http: HttpClient) { }

  //1. Get data from Component
  createContact(contactData: any) {
    console.log(contactData);

    //Using Promises//
    let promise = new Promise((resolve, reject) => {
      this.http.post("http://jsonplaceholder.typicode.com/users", contactData)
        .toPromise()
        .then((res: any) => {
          console.log(res);
          resolve(res);
        })
        .catch(err => {
          console.log(err);
          reject(err);
        })
    });
    return promise;
  }

  getContacts(): any {
    console.log("test");
    return this.http.get(this.API_URL)
      .pipe(map((res: any) => {
        console.log(res);
        return res;
      }));
  }

  getContactById(id) {
    console.log(id);
    return this.http.get(this.API_URL + id)
      .pipe(map((res: any) => {
        console.log(res);
        return res;
      }));
  }

  updateContact(_contactData) {
    console.log(_contactData);
    return this.http.put(this.API_URL + _contactData.id, _contactData)
      .pipe(map((res: any) => {
        console.log(res);
        return res;
      }));
  }
}
