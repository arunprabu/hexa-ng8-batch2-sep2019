import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartDataService } from '../../services/cart-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  defaultCartItemsCount: number;

  constructor(private router: Router, private cartDataService: CartDataService) { }

  ngOnInit() {
    this.cartDataService.latestCartItems.subscribe((pdtList) => {
      this.defaultCartItemsCount = pdtList.length;
    });
  }

  gotoCartPage() {
    this.router.navigate(['products', 'cart']);
  }


}
