import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-found',
  template: `
  <div class="container text-center">
    <div class="row">
        <div class="col-md-12">
            <div>
                <h1>
                    Oops!</h1>
                <h2>
                    404 Not Found</h2>
                <div class="error-details">
                    The page you are looking for doesn't exist!
                </div>
                <div class="error-actions">
                    <a routerLink="/" class="btn btn-primary btn-lg">
                        Take Me Home </a>
                </div>
            </div>
        </div>
    </div>
  </div>
  `,
  styles: []
})
export class PageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
