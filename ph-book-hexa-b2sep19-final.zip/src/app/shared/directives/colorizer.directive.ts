import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appColorizer]'
})
export class ColorizerDirective {

  constructor(private elementRef: ElementRef, private renderer: Renderer2) {
    console.log("inside constructor of Colorizer directive");
    //
    console.log(this.elementRef.nativeElement);
    //using JS alone
    let _el = this.elementRef.nativeElement;
    _el.style.height = "200px";

    //using Renderer2 you can modify DOM Elements
    this.renderer.setStyle(_el, 'background-color', 'red');
  }

}
