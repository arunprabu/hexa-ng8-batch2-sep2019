import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ellipsis'
})
export class EllipsisPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    console.log(value);
    console.log(args); //array
    let limit = args[0];
    if (limit > 0) {
      value = value.substr(0, limit);
    }
    return value + "...";
  }

}
