import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ContactService } from '../contact.service';
import { Contact } from '../contact.model';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styles: []
})
export class AddContactComponent implements OnInit {

  // Step1: create FormGroup
  contactForm: FormGroup;
  isSaved: boolean;

  // Step2: Connect to Service via dep injection
  constructor(private contactService: ContactService) { // Dep Injection
  }

  ngOnInit() {

    // Step 2: Define the FormGroup
    this.contactForm = new FormGroup({
      // Step3: Create FormControls -- For Step4 ref add-contact.comp.html
      name: new FormControl('', Validators.required),  // Step6: adding validators 
      phone: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ])
    });
  }

  async onAddContactSubmit() {
    console.log("submitted");
    // Step1: Get the Data from HTML Form
    console.log(this.contactForm.value);

    const status: Contact = await this.contactService.createContact(this.contactForm.value);

    console.log(status);
    if (status && status.id) {
      this.isSaved = true;
    }

  }
}
