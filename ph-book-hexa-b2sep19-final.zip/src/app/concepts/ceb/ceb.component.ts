import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-ceb',
  templateUrl: './ceb.component.html',
  styles: []
})
export class CebComponent implements OnInit {

  //Step1: Create Custom Event in child Component 
  @Output() onProfileLoaded: EventEmitter<any> = new EventEmitter();

  courseName: string = "Angular";

  constructor() {
    console.log("Inside Constructor");
  }

  //life cycle hook
  ngOnInit() {
    console.log("inside ngOnInit");
  }

  onSendBtnClick() {
    //Step2: Emit custom Event in Child Component  and send the data along with it
    this.onProfileLoaded.emit({ name: 'Arun', city: "Chennai" });
  }
}
