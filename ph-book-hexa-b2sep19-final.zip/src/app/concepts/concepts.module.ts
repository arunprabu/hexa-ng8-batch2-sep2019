import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '../../../node_modules/@angular/router';
import { FormsModule } from '@angular/forms';

import { ConceptsRoutingModule } from './concepts-routing.module';
import { ConceptsComponent } from './concepts.component';
import { CpbComponent } from './cpb/cpb.component';
import { CebComponent } from './ceb/ceb.component';


@NgModule({
  declarations: [
    ConceptsComponent,
    CpbComponent,
    CebComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ConceptsRoutingModule
  ]
})
export class ConceptsModule { }
