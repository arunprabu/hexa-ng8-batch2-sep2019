import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-cpb',
  templateUrl: './cpb.component.html',
  styles: []
})
export class CpbComponent implements OnInit {
  //to receive the data from parent --creating property 
  //@Input() wil make the variable as property
  @Input() exp: number = 20;

  constructor() { }

  ngOnInit() {
  }

}
