import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ConceptsComponent } from './concepts.component';

const CONCEPTS_ROUTES: Routes = [
  { path: 'concepts', component: ConceptsComponent }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(CONCEPTS_ROUTES)
  ],
  exports: [RouterModule]
})
export class ConceptsRoutingModule { }
