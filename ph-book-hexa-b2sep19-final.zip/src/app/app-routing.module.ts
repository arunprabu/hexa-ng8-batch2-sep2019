import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConceptsComponent } from './concepts/concepts.component';
import { AboutComponent } from './about/about.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { PrimengComponent } from './primeng/primeng.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthGuard } from './shared/guards/auth.guard';

// Configuring the routes
const routes: Routes = [
  // syntax: path should be string, component should be the component class
  { path: '', component: ConceptsComponent },
  { path: 'about', component: AboutComponent, canActivate: [AuthGuard] },
  { path: 'signin', component: SigninComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'primeng', component: PrimengComponent, canActivate: [AuthGuard] },
  { path: '**', component: PageNotFoundComponent }  // 404 route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],  // registering the routes
  exports: [RouterModule]
})
export class AppRoutingModule { }
