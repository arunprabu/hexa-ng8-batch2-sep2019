import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primeng',
  templateUrl: './primeng.component.html',
  styles: []
})
export class PrimengComponent implements OnInit {

  date1: Date;

  chartData: any;

  constructor() {
    this.chartData = {
      labels: ['A', 'B', 'C'],
      datasets: [
        {
          data: [300, 50, 100],
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56"
          ],
          hoverBackgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56"
          ]
        }]
    };
  }

  ngOnInit() {
  }

}
