import { Component, OnInit, OnDestroy } from '@angular/core';
import { CartDataService } from '../../shared/services/cart-data.service';
import { Subscription } from '../../../../node_modules/rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styles: []
})
export class CartComponent implements OnInit, OnDestroy {

  cartItemList: any[];
  cartItemsSubscription: Subscription;

  constructor(private cartDataService: CartDataService) { }

  ngOnInit() {
    //Step 3: Subscribe the observable 
    this.cartItemsSubscription = this.cartDataService.latestCartItems.subscribe(pdtList => {
      console.log(pdtList);
      this.cartItemList = pdtList;
    });
  }

  ngOnDestroy() {
    this.cartItemsSubscription.unsubscribe();
  }
}
