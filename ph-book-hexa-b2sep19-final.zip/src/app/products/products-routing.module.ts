import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ProductsComponent } from './products.component';
import { CartComponent } from './cart/cart.component';
import { ProductDetailsComponent } from './product-details/product-details.component';

const PRODUCT_ROUTES: Routes = [
  {
    path: 'products', children: [
      { path: '', component: ProductsComponent },
      { path: 'cart', component: CartComponent },
      { path: ':id', component: ProductDetailsComponent }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(PRODUCT_ROUTES)
  ],
  exports: [RouterModule]
  //after adding child routes, exporting the configured routes to ProductsModule
})
export class ProductsRoutingModule { }
