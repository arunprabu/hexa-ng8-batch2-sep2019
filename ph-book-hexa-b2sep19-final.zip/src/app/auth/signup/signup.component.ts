import { Component, OnInit } from '@angular/core';
import { NgForm } from '../../../../node_modules/@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styles: []
})
export class SignupComponent implements OnInit {

  recentUserData: any;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.authService.updatedUserInfo$.subscribe((_recentUserData: any) => {
      console.log(_recentUserData);
      this.recentUserData = _recentUserData;
    })
  }

  signUpHandler(signupForm: NgForm) {
    console.log(signupForm);
    //1. send this form data to service -- Auth Service  ng g s auth/auth 
    this.authService.signup(signupForm.value);

    //2. get the resp from Auth Service  -- refer the abover observable 

  }
}
