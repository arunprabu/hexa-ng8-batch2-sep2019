import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styles: []
})
export class AboutComponent implements OnInit {

  birthday = new Date(1988, 3, 15);

  loremIpsum: string = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia cum eaque ducimus est nulla libero doloribus enim facilis! Quam id maiores nisi est nemo exercitationem facilis dolorum nostrum libero consequatur.';

  constructor() { }

  ngOnInit() {
  }

}
