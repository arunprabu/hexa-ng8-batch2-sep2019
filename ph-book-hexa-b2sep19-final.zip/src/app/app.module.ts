import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//prime ng modules
import { CalendarModule } from 'primeng/calendar';
import { ChartModule } from 'primeng/chart';

//firebase setup
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { NavComponent } from './shared/components/nav/nav.component';
import { AboutComponent } from './about/about.component';

import { ProductsModule } from './products/products.module';
import { ConceptsModule } from './concepts/concepts.module';
import { ContactsModule } from './contacts/contacts.module';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { PrimengComponent } from './primeng/primeng.component';
import { EllipsisPipe } from './shared/pipes/ellipsis.pipe';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthInterceptor } from './shared/interceptors/auth.interceptors';
import { AuthService } from './auth/auth.service';
import { ColorizerDirective } from './shared/directives/colorizer.directive';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDI7mYVzSBR_xSdoPtkDq_D4E1_4pzmLno",
  authDomain: "hexa-ng-auth-b2.firebaseapp.com",
  databaseURL: "https://hexa-ng-auth-b2.firebaseio.com",
  projectId: "hexa-ng-auth-b2",
  storageBucket: "",
  messagingSenderId: "333443086726",
  appId: "1:333443086726:web:a30008031375ca88c05407"
};

//Main Switching Box 
//Decorator 
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    AboutComponent,
    PageNotFoundComponent,
    PrimengComponent,
    EllipsisPipe,
    SigninComponent,
    SignupComponent,
    ColorizerDirective
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CalendarModule,
    ChartModule,

    AngularFireModule.initializeApp(firebaseConfig),   // will help us connect to firebase app 
    AngularFireAuthModule, // login 
    AngularFirestoreModule, // signup 

    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ContactsModule,
    ProductsModule, // Feature Module imported
    ConceptsModule,
    AppRoutingModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  // Step3: appModule should be bootstrapped with a Component 
  bootstrap: [AppComponent]
})
export class AppModule { }
